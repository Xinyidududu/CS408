#include <stdio.h>

int main() {
    int result = -5 % 2;
    printf("%d\n", result);
    return 0;
}
