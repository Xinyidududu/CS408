result = -5 % 2
print(result)
