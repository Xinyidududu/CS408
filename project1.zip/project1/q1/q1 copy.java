package q1;

public class q1 {
    public static void main(String[] args) {
        int result = -5 % 2;
        System.out.println(result);
    }
}
